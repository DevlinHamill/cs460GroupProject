package com.example.project;
/**
 * @author BT&T
 * CS 460
 */
public class FinanceObj {
    /**
     * keeps track of the amount
     */
    String Amount;
    /**
     * keeps track of the note
     */
    String Note;
    /**
     * keeps track of the current expense or income condititon
     */
    String Condition;
}

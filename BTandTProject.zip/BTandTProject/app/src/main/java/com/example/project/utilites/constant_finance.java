package com.example.project.utilites;
/**
 * @author BT&T
 * CS 460
 */
public class constant_finance {
    /**
     * constant note variable that keeps storing firebase data more consistent
     */
    public static final String KEY_Note ="Note";
    /**
     * constant amount variable that keeps storing firebase data more consistent
     */
    public static final String KEY_Amount ="Amount";
    /**
     * constant collection variable that keeps storing firebase data more consistent
     */
    public static final String KEY_COLLECTION_FINANCE="Finance";
    /**
     * constant condition variable that keeps storing firebase data more consistent
     */
    public static final String KEY_CONDITION = "Condition";

}
